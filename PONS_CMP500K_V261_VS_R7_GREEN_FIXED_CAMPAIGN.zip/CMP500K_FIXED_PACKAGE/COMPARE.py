#!/usr/bin/env python3
import json,sys,hashlib
if len(sys.argv)<5:
    raise SystemExit('usage: COMPARE.py deals.jsonl v261.jsonl r7.jsonl out_prefix')
deals_path,a_path,b_path,prefix=sys.argv[1:5]
def load(path):
    d={}
    with open(path,encoding='utf-8') as f:
        for ln in f:
            if ln.strip():
                x=json.loads(ln); d[int(x['index_global'])]=x
    return d
def csig(c):
    if c.get('passout'): return 'PASSOUT'
    return f"{c.get('level')}{c.get('strain')}@{c.get('declarer')}:{c.get('doubling','NONE')}"
def first_div(a,b):
    aa=a.get('auction',[]); bb=b.get('auction',[])
    n=max(len(aa),len(bb))
    for i in range(n):
        x=aa[i] if i<len(aa) else None; y=bb[i] if i<len(bb) else None
        if x!=y: return i,x,y
    return None,None,None
D=load(deals_path); A=load(a_path); B=load(b_path)
keys=sorted(set(D)&set(A)&set(B))
if len(keys)!=len(D) or len(A)!=len(D) or len(B)!=len(D):
    raise SystemExit(f'coverage mismatch deals={len(D)} v261={len(A)} r7={len(B)} common={len(keys)}')
raw=[]; auction_only=contract_diff=0
for i in keys:
    a,b=A[i],B[i]
    au=a.get('auction')!=b.get('auction'); co=a.get('contract')!=b.get('contract')
    if not (au or co): continue
    j,x,y=first_div(a,b)
    row={
      'index_global':i,'seed':D[i].get('seed'),'dealer':D[i].get('dealer'),'vulnerability':D[i].get('vulnerability'),
      'hands':D[i].get('hands'),
      'first_divergence_ply':j,'v261_first_call':x,'r7_first_call':y,
      'v261_auction':a.get('auction'),'r7_auction':b.get('auction'),
      'v261_contract':a.get('contract'),'r7_contract':b.get('contract'),
      'v261_contract_sig':csig(a.get('contract',{})),'r7_contract_sig':csig(b.get('contract',{})),
      'auction_only_same_contract': au and not co,
      'contract_changed':co,
      'v261_marks':a.get('marks',[]),'r7_marks':b.get('marks',[])
    }
    if row['auction_only_same_contract']: auction_only+=1
    if co: contract_diff+=1
    raw.append(row)
with open(prefix+'_RAW_DIFFERENCES.jsonl','w',encoding='utf-8') as f:
    for r in raw: f.write(json.dumps(r,separators=(',',':'))+'\n')
summary={'deals':len(D),'differences':len(raw),'auction_only_same_contract':auction_only,'contract_changed':contract_diff,'same':len(D)-len(raw)}
with open(prefix+'_RAW_SUMMARY.json','w',encoding='utf-8') as f: json.dump(summary,f,indent=2)
print(json.dumps(summary))
