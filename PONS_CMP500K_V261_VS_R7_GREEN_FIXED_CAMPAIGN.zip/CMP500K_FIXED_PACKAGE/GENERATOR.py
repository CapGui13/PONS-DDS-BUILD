#!/usr/bin/env python3
import json,sys
MASK=(1<<64)-1
RANKS='AKQJT98765432'
SUITS='SHDC'
SEATS='NESW'
VUL=['None','NS','EW','Both','NS','EW','Both','None','EW','Both','None','NS','Both','None','NS','EW']
class SplitMix64:
    def __init__(self,seed): self.x=seed&MASK
    def next(self):
        self.x=(self.x+0x9E3779B97F4A7C15)&MASK
        z=self.x
        z=((z^(z>>30))*0xBF58476D1CE4E5B9)&MASK
        z=((z^(z>>27))*0x94D049BB133111EB)&MASK
        return (z^(z>>31))&MASK
    def bounded(self,n):
        # exact rejection, no modulo bias
        limit=((1<<64)//n)*n
        while True:
            x=self.next()
            if x<limit: return x%n

def deal_for(seed):
    deck=[(s,r) for s in SUITS for r in RANKS]
    rng=SplitMix64(seed)
    for i in range(51,0,-1):
        j=rng.bounded(i+1)
        deck[i],deck[j]=deck[j],deck[i]
    hands={p:{s:'' for s in SUITS} for p in SEATS}
    rankpos={r:i for i,r in enumerate(RANKS)}
    for pi,p in enumerate(SEATS):
        for s,r in deck[13*pi:13*(pi+1)]: hands[p][s]+=r
        for s in SUITS: hands[p][s]=''.join(sorted(hands[p][s], key=rankpos.get))
    return hands

def main(path,count=50000,master=202610220000):
    with open(path,'w') as f:
        for i in range(count):
            seed=master+i
            o={'index_global':i,'seed':seed,'dealer':SEATS[i%4],'vulnerability':VUL[i%16],'hands':deal_for(seed)}
            f.write(json.dumps(o,separators=(',',':'))+'\n')
if __name__=='__main__':
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv)>2 else 50000, int(sys.argv[3]) if len(sys.argv)>3 else 202610220000)
