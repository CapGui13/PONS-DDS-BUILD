import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const runtime=process.argv[2], input=process.argv[3], output=process.argv[4];
if(!runtime||!input||!output) throw new Error('usage runtime input output');
console.info=()=>{}; console.warn=()=>{};
await import(pathToFileURL(path.join(runtime,'pons-semantic.js')).href+'?x='+Date.now());
await import(pathToFileURL(path.join(runtime,'pons-critic.js')).href+'?x='+Date.now());
const wasmMod=await import(pathToFileURL(path.join(runtime,'pons/pkg/pons_wasm.js')).href+'?x='+Date.now());
await wasmMod.default(fs.readFileSync(path.join(runtime,'pons/pkg/pons_wasm_bg.wasm')));
const SEATS=['N','E','S','W'], SR={C:0,D:1,H:2,S:3,NT:4};
const side=s=>(s==='N'||s==='S')?'NS':'EW';
const parse=c=>{const m=String(c||'').match(/^([1-7])(NT|[CDHS])$/);return m?{level:+m[1],strain:m[2]}:null};
const rank=c=>{const b=parse(c);return b?(b.level-1)*5+SR[b.strain]:-1};
function over(h){const any=h.some(x=>parse(x.call));return any?h.length>=3&&h.slice(-3).every(x=>x.call==='PASS'):h.length>=4&&h.slice(-4).every(x=>x.call==='PASS')}
function lastNP(h){for(let i=h.length-1;i>=0;i--)if(h[i].call!=='PASS')return h[i];return null}
function lastB(h){for(let i=h.length-1;i>=0;i--)if(parse(h[i].call))return h[i];return null}
function legal(h,c,seat){if(over(h))return false;if(c==='PASS')return true;const l=lastNP(h);if(c==='X')return !!l&&!!parse(l.call)&&side(l.seat)!==side(seat);if(c==='XX')return !!l&&l.call==='X'&&side(l.seat)!==side(seat);const b=parse(c);if(!b)return false;const lb=lastB(h);return !lb||rank(c)>rank(lb.call)}
const hstr=(d,s)=>[d.hands[s].S||'',d.hands[s].H||'',d.hands[s].D||'',d.hands[s].C||''].join('.');
const astr=h=>h.map(x=>x.call==='PASS'?'P':x.call).join(' ');
function pons(text){let s=String(text||'');const cut=s.lastIndexOf('|');s=(cut>=0?s.slice(0,cut):s).trim().toUpperCase();if(s==='P'||s==='PASS')return'PASS';if(s==='X'||s==='DOUBLE')return'X';if(s==='XX'||s==='REDOUBLE')return'XX';if(/^([1-7])(C|D|H|S|NT)$/.test(s))return s;const m=s.match(/LEVEL\((\d)\).*?(CLUBS|DIAMONDS|HEARTS|SPADES|NOTRUMP)/i);if(!m)throw new Error('unknown '+s);return m[1]+({CLUBS:'C',DIAMONDS:'D',HEARTS:'H',SPADES:'S',NOTRUMP:'NT'}[m[2].toUpperCase()])}
function diag(d,s,h){try{return JSON.parse(wasmMod.pons_diagnose(hstr(d,s),astr(h),d.dealer,d.vulnerability))}catch{return null}}
function contract(h){const b=lastB(h);if(!b)return{passout:true};const pb=parse(b.call),si=side(b.seat);let dec=b.seat;for(const e of h){const p=parse(e.call);if(p&&side(e.seat)===si&&p.strain===pb.strain){dec=e.seat;break}}const i=h.lastIndexOf(b),a=h.slice(i+1);return{passout:false,level:pb.level,strain:pb.strain,declarer:dec,doubling:a.some(x=>x.call==='XX')?'XX':a.some(x=>x.call==='X')?'X':'NONE'}}
async function decide(d,seat,h){let native;try{native=pons(wasmMod.pons_bid_v2(hstr(d,seat),astr(h),d.dealer,d.vulnerability))}catch{native='PASS'}if(!legal(h,native,seat))native='PASS';const diagnosis=native==='PASS'?diag(d,seat,h):null;const sc=globalThis.PonsSemanticLedger.beforeDecision({seat,deal:d,history:h,diagnosis,infer:null});let final=native,source='pons';const rev=globalThis.PonsCritic.review({seat,deal:d,history:h,call:native,diagnosis,semanticContext:sc,isLegal:(hh,c,s)=>legal(hh,c,s)});if(rev?.changed&&rev.call&&legal(h,rev.call,seat)){final=rev.call;source='critic'}const g=globalThis.PonsSemanticLedger.guardDecision({seat,deal:d,history:h,call:final,diagnosis,semanticContext:sc,isLegal:(hh,c,s)=>legal(hh,c,s)});if(g?.changed&&g.call&&legal(h,g.call,seat)){final=g.call;source='semantic'}globalThis.PonsSemanticLedger.recordDecision({seat,deal:d,history:h,call:final,originalCall:native,source,criticReview:rev,infer:null});const sem=rev?.semantic||null;return{call:final,source,reviewedSource:sem?.source||null,convention:sem?.convention||null,artificialType:sem?.artificialType||null,semanticRole:sem?.semanticRole||null,natural:sem?.natural??null}}
async function play(d){globalThis.PonsSemanticLedger.clear();const h=[], marks=[];for(let i=0;i<80&&!over(h);i++){const seat=SEATS[(SEATS.indexOf(d.dealer)+i)%4],r=await decide(d,seat,h);h.push({seat,call:r.call});if(r.source!=='pons'||r.reviewedSource||r.convention)marks.push({i,seat,...r})}if(!over(h))throw new Error('not over '+d.seed);return{auction:h.map(x=>x.call),contract:contract(h),marks}}
const fd=fs.openSync(output,'w');let n=0;
for(const line of fs.readFileSync(input,'utf8').split(/\r?\n/)){if(!line)continue;const x=JSON.parse(line);const d={dealer:x.dealer,vulnerability:x.vulnerability,vulnerable:x.vulnerability,hands:x.hands,board:x.index_global};const r=await play(d);fs.writeSync(fd,JSON.stringify({index_global:x.index_global,seed:x.seed,dealer:x.dealer,vulnerability:x.vulnerability,auction:r.auction,contract:r.contract,marks:r.marks})+'\n');if(++n%5000===0)process.stderr.write(`done ${n}\n`)}
fs.closeSync(fd);
