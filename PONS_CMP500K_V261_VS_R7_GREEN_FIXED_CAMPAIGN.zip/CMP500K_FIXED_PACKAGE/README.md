# PONS 500K v2.61 vs R7 GREEN — fixed harness rerun

This package reruns the exact original 5×100K paired campaign with **no runtime patch**.

The original benchmark runner built the JS deal object with `vulnerability` only, while the JS critic/semantic/engine layers read `deal.vulnerable`. The fixed runner preserves `vulnerability` for WASM and adds the alias `vulnerable: x.vulnerability` for the JS layers.

Everything else stays fixed: original v2.61 baseline, sealed R7 GREEN candidate, generator, seeds, comparator, and paired deals.

The previous performance verdict is forensic evidence only and must not drive product patches.
