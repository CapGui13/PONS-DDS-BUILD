#!/usr/bin/env python3
import json,sys,collections
base,cand,out=sys.argv[1:4]
def load(p):
 d={}
 with open(p) as f:
  for line in f:
   x=json.loads(line); d[(int(x['index_global']),int(x['seed']))]=x
 return d
A=load(base);B=load(cand)
assert A.keys()==B.keys()
st=collections.Counter(); bad=[]; exact=[]
for k,a in A.items():
 b=B[k]; st['deals']+=1
 if a['auction']==b['auction']:
  st['same']+=1; continue
 st['changed']+=1
 n=min(len(a['auction']),len(b['auction']))
 i=next((j for j in range(n) if a['auction'][j]!=b['auction'][j]),n)
 am=next((m for m in a.get('marks',[]) if m.get('i')==i),None)
 bm=next((m for m in b.get('marks',[]) if m.get('i')==i),None)
 ok=(i<n and am and am.get('reviewedSource')=='instance-d-wave2-d9-natural-six-card-two-level-overcall' and a['auction'][i] in ('2C','2D','2H') and b['auction'][i]=='PASS' and bm and bm.get('reviewedSource')=='r7-fixed-mb01-d9-suppress-weak-six-card-two-level-overcall')
 if ok:
  st['exact_d9']+=1
  exact.append({'index_global':k[0],'seed':k[1],'ply':i,'r7_green_call':a['auction'][i],'mb01_call':b['auction'][i]})
 else:
  st['collateral']+=1
  bad.append({'index_global':k[0],'seed':k[1],'ply':i,'r7_green_call':a['auction'][i] if i<len(a['auction']) else None,'mb01_call':b['auction'][i] if i<len(b['auction']) else None,'r7_green_mark':am,'mb01_mark':bm})
res={'status':'SHARD_PASS' if st['collateral']==0 else 'SHARD_FAIL',**st,'collateral_examples':bad[:20]}
json.dump(res,open(out,'w'),indent=2)
print(json.dumps(res))
if st['collateral']!=0:sys.exit(4)
