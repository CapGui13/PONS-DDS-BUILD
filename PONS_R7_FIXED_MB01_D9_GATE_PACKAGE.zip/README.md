# R7 FIXED MB01 D9 fresh gate

Baseline: sealed R7 GREEN.
Candidate: one-file MB01 D9 overlay.
Gate: 5 x 10,000 fresh paired deals = 50,000 total.
Pass condition: every R7 GREEN -> MB01 change must first diverge on the exact D9 rule, with MB01 replacing 2C/2D/2H by PASS; collateral must be zero.
No other runtime modification is permitted.
